Интструменты для быстрой и комфортной разработки веб-приложений.

#### Платформа
Для корректной работы необходимы Node.js, Gulp.js и модули к нему.
* Node.js >= 0.10.33
* Gulp.js >= 3.0.8
* NPM >= 1.4.28

Модули
#### Модули
gulp coffee-script gulp-coffee gulp-connect gulp-clean gulp-uglify gulp-sass colors gulp-include gulp-cssmin gulp-rename gulp-filelist gulp-using map-stream gulp-plumber

<a href="http://divisory.github.io/apertura/dist/">Документация</a>